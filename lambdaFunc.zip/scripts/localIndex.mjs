#!/usr/bin/env node

import { handler } from "../index.mjs";

handler({});
