// CONST
export const SERVER_IP = "37.27.9.86";
